﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace WhoLends.Models
{
    public class Lend
    {
        public int ID { get; set; }

        [DisplayName("Gegenstand")]
        public string LendObjectName { get; set; }
        public string LendObjectDescription { get; set; }
        public DateTime From { get; set; }
        public DateTime To { get; set; }
        public string Employee { get; set; }
    }

    public class LendDBContext : DbContext
    {
        public DbSet<Lend> LendsList { get; set; }
    }
}